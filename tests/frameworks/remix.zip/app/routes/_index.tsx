export default function Index() {
  return <h1>hyze remix</h1>;
}
