export default defineNuxtConfig({});
