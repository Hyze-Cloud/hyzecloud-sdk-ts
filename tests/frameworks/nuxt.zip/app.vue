<template>
  <h1>hyze nuxt</h1>
</template>
