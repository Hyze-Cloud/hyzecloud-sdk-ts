const http = require("http");
const port = Number(process.env.PORT || process.env.EXPOSE_PORT || 3000);
const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/plain" });
  res.end("hyze node\n");
});
server.listen(port, () => {
  console.log("hyze node-api listening on", port);
});
