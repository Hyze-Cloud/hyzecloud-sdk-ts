export default function App() {
  return <h1>hyze vite</h1>;
}
