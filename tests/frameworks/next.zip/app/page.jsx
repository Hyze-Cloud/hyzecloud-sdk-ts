export default function Home() {
  return <h1>hyze next</h1>;
}
